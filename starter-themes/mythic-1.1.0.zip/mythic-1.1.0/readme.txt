=== Mythic ===

Contributors: greenshady
Tags:
Requires at least: 4.9
Tested up to: 5.0
Requires PHP: 5.6
Stable tag: 1.0.0
License: GNU General Public License v2.0 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Short description of the theme.

== Description ==

This file is a base template to build out your `readme.txt`, which is a requirement for WordPress.org.  If not distributing on that platform, feel free to delete.

Formatting instructions: https://make.wordpress.org/themes/2015/04/29/a-revised-readme/

== Installation ==

== Changelog ==

== Upgrade Notice ==
