<?php Hybrid\Pagination\display( 'comments', [
	'prev_text'  => __( '&larr; Previous' ),
	'next_text'  => __( 'Next &rarr;' ),
	'title_text' => __( 'Comments Navigation' ),
	'title_tag'  => 'h3'
] );
