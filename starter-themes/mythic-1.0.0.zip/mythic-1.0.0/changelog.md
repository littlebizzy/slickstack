# Change Log

## [1.0.0] - 2018-09-18

### Added

* Everything's new!
