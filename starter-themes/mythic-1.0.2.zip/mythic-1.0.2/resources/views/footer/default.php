	<footer class="app-footer">

		<p class="app-footer__credit">
			<?php esc_html_e( 'Powered by crazy ideas and passion.' ) ?>
		</p>

	</footer>

</div><!-- .app -->

<?php wp_footer() ?>
</body>
</html>
