<?php Hybrid\Pagination\display( 'posts', [
	'prev_text'  => __( '&larr; Previous' ),
	'next_text'  => __( 'Next &rarr;' ),
	'title_text' => __( 'Posts Navigation' )
] );
