=== Disable Empty Trash ===

Contributors: littlebizzy
Tags: disable empty trash, disable, empty, trash, can, bin, automatic, emptying, purge, purging
Requires at least: 4.4
Tested up to: 4.8
Stable tag: 1.0.0
License: GPL3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Completely disables the automatic trash empty for WordPress posts, custom posts, pages, and comments to avoid data loss and encourage manual emptying.

== Description ==

Completely disables the automatic trash empty for WordPress posts, custom posts, pages, and comments to avoid data loss and encourage manual emptying.

== Installation ==

1. Upload "Disable Empty Trash" folder to the "/wp-content/plugins/" directory
2. Activate the plugin through the "Plugins" menu in WordPress

== Changelog ==

= 1.0.0 =
* initial release
