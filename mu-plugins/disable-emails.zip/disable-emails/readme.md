# Disable Emails #

Stop WordPress from sending any emails. ANY!

* [GitHub](https://github.com/webaware/disable-emails)
* [Readme](https://github.com/webaware/disable-emails/blob/master/readme.txt)
* [Download](https://wordpress.org/plugins/disable-emails/)
* [Documentation](https://wordpress.org/plugins/disable-emails/faq/)
* [Support](https://wordpress.org/support/plugin/disable-emails)
* [Translate](https://translate.wordpress.org/projects/wp-plugins/disable-emails)
* [Donate](https://shop.webaware.com.au/donations/?donation_for=Disable+Emails)
