## Changelog

### 1.1.0
* added `index.php` to make WordPress recognize the theme
* added `wp_cache_flush` to clear object cache
* added inline credit to iThemes
* minor code tweaks

### 1.0.0
* inspired by iThemes
* do not use this version (incomplete)
