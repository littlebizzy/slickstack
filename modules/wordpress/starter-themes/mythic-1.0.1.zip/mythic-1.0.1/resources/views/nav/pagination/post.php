<?php Hybrid\Pagination\display( 'post', [
	'show_all'    => true,
	'prev_next'   => false,
	'title_text'  => __( 'Pages:' ),
	'title_class' => 'pagination__title'
] );
