# Disable Attachment Pages

Disables attachment page URLs

## Changelog

### 1.0.0
- initial release
- tested with PHP 7.0, 7.1, 7.2
- tested with PHP 5.6 (no fatal errors only)
- uses PHP namespaces
- object-oriented codebase
- all media attachment pages will become "404 Not Found" errors
- (currently does not work with 404 To Homepage however)
