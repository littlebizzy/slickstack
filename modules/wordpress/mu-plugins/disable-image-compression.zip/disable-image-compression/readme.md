# Disable Image Compression

Disables all JPEG compression

## Changelog

### 2.0.4
- removed the `int` return type hint for classic WordPress PHP style
- clarified inline code comments
- bumped `Tested up to` to 7.0

### 2.0.3
- removed `int` from parameter for PHP 7.0 compatibility
- now only uses the `int` return type hint
- optimized spacing and syntax
- added `Tested up to` header
- added `Update URI` header
- added `Text Domain` header

### 2.0.2
- added `Requires PHP` plugin header
- improved `gu_override_dot_org` snippet

### 2.0.1
- fixed `gu_override_dot_org` snippet

### 2.0.0
- completely refactored code to WordPress standards
- no more PHP classes
- maintains support for Git Updater
- supports PHP 7.0 to 8.3
- supports Multisite

### 1.1.0
- cleaned up plugin files
- removed admin notice script
- added support for Git Updater
- added disable wordpress.org updates snippet

### 1.0.2
- added recommended plugins admin notice
- release files unavailable

### 1.0.1
- tested with WordPress 4.8
- release files unavailable

### 1.0.0
- initial release