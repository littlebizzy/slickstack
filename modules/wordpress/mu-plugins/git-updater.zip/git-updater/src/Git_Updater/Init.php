<?php
/**
 * Git Updater
 *
 * @author   Andy Fragen
 * @license  GPL-3.0-or-later
 * @link     https://github.com/afragen/git-updater
 * @package  git-updater
 */

namespace Fragen\Git_Updater;

use Fragen\Singleton;
use Fragen\Git_Updater\Traits\GU_Trait;
use Fragen\Git_Updater\Traits\Basic_Auth_Loader;

/*
 * Exit if called directly.
 */
if ( ! defined( 'WPINC' ) ) {
	die; // @codeCoverageIgnore
}

/**
 * Class Init
 */
class Init {
	use GU_Trait;
	use Basic_Auth_Loader;

	/**
	 * Holds Class Base object.
	 *
	 * @var Base $base
	 */
	protected $base;

	/**
	 * Constuctor.
	 *
	 * @return void
	 */
	public function __construct() {
		$this->load_options();
		$this->base = Singleton::get_instance( 'Base', $this );
	}

	/**
	 * Let's get going.
	 *
	 * @return void
	 */
	public function run() {
		if ( ! static::is_heartbeat() ) {
			$this->load_hooks();
		}

		if ( static::is_wp_cli() ) {
			// @codeCoverageIgnoreStart
			include_once __DIR__ . '/WP_CLI/CLI.php';
			include_once __DIR__ . '/WP_CLI/CLI_Integration.php';

			Singleton::get_instance( 'Plugin', $this )->get_remote_plugin_meta();
			add_filter( 'site_transient_update_plugins', [ Singleton::get_instance( 'Plugin', $this ), 'update_site_transient' ], 15, 1 );

			Singleton::get_instance( 'Theme', $this )->get_remote_theme_meta();
			add_filter( 'site_transient_update_themes', [ Singleton::get_instance( 'Theme', $this ), 'update_site_transient' ], 15, 1 );
			// @codeCoverageIgnoreEnd
		}
	}

	/**
	 * Load relevant action/filter hooks.
	 * Use 'init' hook for user capabilities.
	 *
	 * @return void
	 */
	protected function load_hooks() {
		add_action( 'init', [ $this->base, 'load' ] );
		add_action( 'init', [ $this->base, 'background_update' ] );
		add_action( 'init', [ $this->base, 'set_options_filter' ] );

		// Load hook for adding authentication headers for download packages.
		add_filter(
			'upgrader_pre_download',
			function (): bool {
				add_filter( 'http_request_args', [ $this, 'download_package' ], 15, 2 );
				return false; // upgrader_pre_download filter default return value.
			}
		);
		add_filter( 'upgrader_source_selection', [ $this->base, 'upgrader_source_selection' ], 10, 4 );

		// Add git host icons.
		add_filter( 'plugin_row_meta', [ $this->base, 'row_meta_icons' ], 15, 2 );
		add_filter( 'theme_row_meta', [ $this->base, 'row_meta_icons' ], 15, 2 );

		// Check for deletion of cron event.
		add_filter( 'pre_unschedule_event', [ Singleton::get_instance( 'GU_Upgrade', $this ), 'pre_unschedule_event' ], 10, 3 );
	}

	/**
	 * Checks current user capabilities.
	 *
	 * Use 'manage_options' capability so when DISALLOW_FILE_MODS is true,
	 * Git Updater can still function.
	 *
	 * @return bool
	 */
	public function can_update() {
		// WP-CLI access has full capabilities.
		if ( static::is_wp_cli() ) {
			return true; // @codeCoverageIgnore
		}

		return current_user_can( 'manage_options' );
	}
}
