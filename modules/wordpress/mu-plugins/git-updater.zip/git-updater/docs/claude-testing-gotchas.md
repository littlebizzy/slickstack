## Testing gotchas

### REST API test setup
Always use `rest_get_server()` — never instantiate `WP_REST_Server` directly or call `register_endpoints()` manually. WordPress enforces that `register_rest_route()` is called inside the `rest_api_init` hook. `rest_get_server()` fires that hook automatically. Reset between tests with `$GLOBALS['wp_rest_server'] = null` before calling `rest_get_server()`.

### Composer platform pin
`composer.json` pins `"platform": {"php": "8.2"}`. Do not change this. Without it, Composer running on PHP 8.3+ resolves `doctrine/instantiator` 2.1.0, which uses typed class constants (`private const string …`) — PHP 8.3+ syntax — causing a parse error in the PHP 8.2 wp-env container that silently fails all tests in the affected file.

### HTTP mocking with `pre_http_request`
Mock all outbound HTTP via the `pre_http_request` filter (not `wp_remote_get` stubs). Return a `WP_Error` to short-circuit, or a properly structured response array: `['response' => ['code' => 200], 'body' => '...', 'headers' => []]`. Convenience helper `http_response(string $body, int $code = 200)` is available in `WP_Http_TestCase`-derived test classes.

### Error cache contamination
Any non-200 HTTP response from `API::api()` writes a 60-minute error cache entry (`ghu-<md5(slug_error)>` site option). Subsequent calls within that window return `false` immediately without hitting the network. In tests: ensure mocks return 200 for all paths, or delete the error site option in `tear_down()`.

### `convertNoticesToExceptions` is on
`phpunit.xml` sets `convertNoticesToExceptions="true"`. Undefined array key accesses (PHP 8 notices) fail tests immediately. Always initialise array keys before access, or use `isset()` / `??` guards.

### api.wordpress.org update-check mocks
WordPress core's `wp_update_plugins()` does `json_decode($body, true)` then directly accesses `$response['plugins']`. Return the correct structure to avoid undefined-key failures:
- Plugins: `{"plugins": [], "translations": [], "no_update": []}`
- Themes: `{"themes": [], "translations": [], "no_update": []}`

### Fixture plugin path in `.wp-env.json`
Plugin paths must be prefixed with `./` (e.g. `"./tests/fixtures/plugins/test-gu-plugin"`). Without the prefix, wp-env treats the string as a `owner/repo` GitHub slug and fails with "repository not found".

### Trait test pattern: use `GitHub_API`, not trait-on-test-class
Methods that call `get_class_vars()` (e.g. `set_repo_cache`, `get_error_codes`) rely on `Singleton::get_instance('API\API', ...)` resolving relative to the caller's namespace. When called from a global-namespace test class the resolution fails. Always instantiate `GitHub_API` and call trait methods through it.

### `get_remote_api_info()` success path requires dot_org cache pre-seeding
`get_remote_api_info()` (called via `GitHub_API::get_remote_info()`) invokes `get_dot_org_data()`, which hits `api.wordpress.org` unless the main cache already contains a `dot_org` key. Pre-seed it in the test:
```php
update_site_option( $this->api->get_cache_key('test-plugin'), [
    'dot_org' => 'not in dot org',
    'timeout' => strtotime('+12 hours'),
] );
```

### `get_remote_api_info()` cache-extend path — use expired timeout, not `seed_cache()`
To test the path where `maybe_extend_repo_cache()` returns `true` (all `ran` complete, versions match) causing `get_remote_api_info()` to return `false`, seed the cache with an **expired** timeout rather than a valid one. A valid-timeout cache causes `$response = $cache[$slug]` to be truthy, skipping `api()` — then `set_file_info()` receives the incomplete seeded array and throws an undefined-key notice.

Seed with `strtotime('-1 hour')` so `get_repo_cache($slug)` returns `false` (forcing an `api()` call), but the raw site option still holds the old version for `get_repo_cache($slug, false)`:
```php
update_site_option(
    $this->api->get_cache_key( 'test-plugin' ),
    [
        'timeout'     => strtotime( '-1 hour' ),
        'repo'        => 'test-plugin',
        'test-plugin' => [ 'Version' => '1.0.0' ],   // old version — must match API response
        'ran'         => [ 'contents', 'assets', 'readme', 'changes', 'tags', 'branches', 'meta' ],
    ]
);
```

### `maybe_extend_repo_cache()` — always pass explicit `$old_version` in direct tests
`maybe_extend_repo_cache( $remote_headers, $repo, $old_version = '' )` compares the new remote version against `$old_version`. The default `''` never equals any real version string, so omitting the argument means the version-match branch (the extend path) is unreachable. Direct test calls that exercise the extend path must pass the matching old version as the third argument:
```php
$this->api->maybe_extend_repo_cache( [ 'Version' => '1.0.0' ], $this->type, '1.0.0' );
```
Tests for the version-mismatch (no extend) path pass a different old version:
```php
$this->api->maybe_extend_repo_cache( [ 'Version' => '2.0.0' ], $this->type, '1.0.0' );
```

### `parse_release_asset()` does not guard against `false`
`parse_release_asset()` checks `is_wp_error($response)` but not `false`. If `api()` returns `false` (via error cache) the subsequent `foreach($response as $release)` throws a TypeError. When testing failure paths for `get_release_assets()`, use a `WP_Error` mock via `pre_http_request` rather than seeding the error cache:
```php
add_filter('pre_http_request', fn() => new WP_Error('http_request_failed', 'Connection refused'), 10, 3);
```

### Cron scheduling in tests: use past timestamps
`wp_get_ready_cron_jobs()` only returns events with a timestamp ≤ `time()`. Scheduling with `time() + HOUR_IN_SECONDS` (future) makes the event invisible. Use `time() - HOUR_IN_SECONDS` (1 hour ago) — past-due but within the 24-hour `is_cron_overdue()` window, so no error is triggered.

### `get_api_release_assets()` / `get_api_release_asset()` always fetch when not cached
These methods no longer have an `exit_no_update()` guard. They always make an API call when `$cache['release_assets']` / `$cache['release_asset']` is absent, regardless of whether the repo has a pending update. This is intentional: release asset data is needed by the REST `update-api` endpoint even when a repo is at its latest version. Tests for these methods must NOT add `add_filter('gu_always_fetch_update', '__return_true')` — that filter is now only relevant to methods that still contain the guard (e.g. `get_release_asset_redirect()`).

Note: `get_api_release_assets()` calls `get_repo_cache($slug)` with the default `$timeout=true`, meaning an expired cache returns `false` and triggers a fresh API call. This differs from `construct_download_link()` and `populate_api_data()`, which both call `get_repo_cache(..., false)` (bypass timeout).

### `get_api_release_asset()` is commented out in GitHub_API
`GitHub_API::get_release_asset()` has its body commented out; calling it is a no-op. The underlying trait method `get_api_release_asset()` is `final public` and can be invoked directly in tests:
```php
$this->api->get_api_release_asset( 'github', '/repos/test-owner/test-plugin/releases/latest' );
```

### Dev-release tag format for `parse_release_asset()`
The dev-release regex `/[^v]+(?:nightly|alpha|beta|RC){1}[0-9]{0,}/i` requires at least one non-`v` character *before* the keyword. A bare `beta1` does not match; use `1.0.0-beta1`, `2.0.0-nightly20240601`, etc.

### Testing cache-hit paths: `seed_main_cache()` helper pattern
Pre-populate the main site option to drive the cached branch without HTTP. Merge with a future timeout so `get_repo_cache()` doesn't reject the entry:
```php
update_site_option(
    $this->api->get_cache_key( 'test-plugin' ),
    array_merge( [ 'timeout' => strtotime( '+12 hours' ) ], $data )
);
```
Methods that use `get_repo_cache($slug, false)` (ignore timeout) also read stale entries, so the timeout value doesn't matter for those callers.

### `get_addon_api_results()` uses `wp_remote_post`, interceptable via `pre_http_request`
`Add_Ons::get_addon_api_results()` calls `wp_remote_post()` for each of the four add-on slugs. Mock all outbound HTTP via `add_filter('pre_http_request', ...)` — the filter intercepts POST requests too. Results are cached only when all four addons succeed (count check); partial results are returned but not cached. Cache key is `ghu-` + md5('gu_addon_api_results').

### `Add_Ons::add_settings_tabs()` closure (line 70) — fire `gu_add_admin_page` with two args
The closure registered on `gu_add_admin_page` by `add_settings_tabs()` is only covered when that action is fired. Call `$addons->add_settings_tabs()` then `do_action('gu_add_admin_page', 'git_updater_addons', admin_url())`. Two args are required: `Additions\Settings` also registers on this action with `$accepted_args=2`; passing only one arg causes an `ArgumentCountError`. The `Add_Ons` closure uses `$accepted_args=1` so it safely ignores the second arg.

### `Add_Ons::add_admin_page()` — assert on `ajax-activate`, not `plugin-install`
`add_admin_page('git_updater_addons')` calls `wp_enqueue_script('plugin-install')` (enqueue-only, no register) plus registers-and-enqueues `ajax-activate` with a full URL. `plugin-install` may already be in `done` state from prior tests, making `wp_script_is('plugin-install', 'enqueued')` unreliable. Assert `wp_script_is('ajax-activate', 'registered')` instead — `ajax-activate` is freshly registered by the method. Dequeue and deregister `ajax-activate` in both `set_up()` and `tear_down()` to prevent cross-test contamination.

### `Add_Ons::insert_cards()` — load `template.php`, set screen, and supply full item schema
`insert_cards()` calls `_get_list_table('WP_Plugin_Install_List_Table')`, which is defined in `wp-admin/includes/template.php` — load it in `set_up()`. The list table's `display()` is safe without full admin context but requires a screen object: call `set_current_screen('plugin-install')` before invoking `insert_cards()` and reset `$GLOBALS['current_screen'] = null` in `tear_down()`. Capture output with `ob_start()`/`ob_get_clean()`. Items must include all keys accessed by `single_row()` to avoid undefined-key notices under `convertNoticesToExceptions`. Required keys (beyond `name`/`slug`/`version`): `short_description`, `author`, `author_profile`, `rating`, `num_ratings`, `active_installs`, `downloaded`, `last_updated`, `requires`, `requires_php`, `tested`, `homepage`, `group`, `icons` (array with `'default'` key), `action_links`, `banners`, `donate_link`, `compatibility`.

### Additions\Settings has a static `$options_additions` property
`Settings::$options_additions` is a static property populated in `__construct()` from `get_site_option('git_updater_additions', [])`. In tests, reset it before constructing: `Additions_Settings::$options_additions = []`. Set it directly on the class (not via site option) to drive `callback_checkbox()` checked-state tests.

### Repo_List_Table requires WP_List_Table to be loaded
`Repo_List_Table` extends `WP_List_Table`. The file-level guard loads it automatically when the class file is autoloaded, but as belt-and-suspenders add `require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php'` in `set_up()`. The constructor works in the tests-cli container without full admin context; `get_current_screen()` returns null but does not error.

### `wp_theme_update_row()` echoes directly; requires WP_Plugins_List_Table
`Theme::wp_theme_update_row()` echoes HTML directly — capture it with `ob_start()`/`ob_get_clean()`. It calls `$this->base->update_row_enclosure()` which internally calls `_get_list_table('WP_Plugins_List_Table')`. Load the needed admin includes in `set_up()`:
```php
require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
require_once ABSPATH . 'wp-admin/includes/class-wp-plugins-list-table.php';
require_once ABSPATH . 'wp-admin/includes/template.php'; // defines _get_list_table
```
All three are available in the wp-env tests-cli container. The early-return path (when `$theme_key` is absent from `update_themes->response`) produces no output and needs no admin setup.

### `Additions::deduplicate()` reads plugin/theme cache with full timeout check
`deduplicate()` calls `get_repo_cache('git_updater_repository_add_plugin')` and `get_repo_cache('git_updater_repository_add_theme')` with the default `$timeout = true`. Seed these site options with a future `timeout` key or the cache will be ignored: `update_site_option('ghu-' . md5('git_updater_repository_add_plugin'), ['git_updater_repository_add_plugin' => [...], 'timeout' => strtotime('+12 hours')])`.

### Cron clearing after transaction rollback: bust the object cache first
`wp_clear_scheduled_hook($hook)` and `wp_unschedule_hook($hook)` read the cron schedule from the WordPress object cache before writing. After a WP_UnitTestCase DB transaction rollback the object cache can be stale — the DB holds the original (bootstrap-scheduled) cron event but the cache reflects the cleared state written by the previous test's `tear_down()`. Calling `wp_clear_scheduled_hook` against a stale cache is a no-op that leaves the DB event in place.

Always bust the cache before clearing cron hooks in `set_up()` and `tear_down()`:
```php
wp_cache_delete( 'cron', 'options' );
wp_unschedule_hook( 'gu_get_remote_plugin' );
```

The `gu_get_remote_plugin` hook is bootstrapped at `init` time (via `Base::load()` → `get_meta_plugins()`) so it will always be present in the pre-test DB state.

### `merge_and_reschedule_cron_batch()` replaces `is_cron_event_scheduled()` at scheduling sites
`Plugin::get_remote_plugin_meta()` and `Theme::get_remote_theme_meta()` call `merge_and_reschedule_cron_batch($hook, $repos)` instead of the old guard+schedule pattern. The helper:
1. Busts the object cache (`wp_cache_delete('cron', 'options')`) so it reads fresh DB state.
2. Reads `_get_cron_array()` and iterates **all** timestamps (no `break`), merging every existing event's `args[0]` into `$new_args` (slug-keyed, so deduplication is automatic).
3. Calls `wp_unschedule_hook($hook)` to clear all existing entries.
4. Schedules exactly one consolidated event.

`is_cron_event_scheduled()` is retained for read-only queries but is no longer called at the scheduling sites.

**Testing count-based assertions:** use `cron_hook_count()` (available in both `Test_Plugin_Methods` and `Test_Theme_Methods`) rather than just `cron_hook_exists()`. The helper busts the cache before counting so it reflects DB truth:
```php
private function cron_hook_count( string $hook ): int {
    wp_cache_delete( 'cron', 'options' );
    $count = 0;
    foreach ( (array) _get_cron_array() as $hooks ) {
        if ( isset( $hooks[ $hook ] ) ) {
            $count += count( $hooks[ $hook ] );
        }
    }
    return $count;
}
```

**Multi-timestamp pre-seeding:** to simulate race-left duplicates at different timestamps, schedule two events with different args (different MD5) at timestamps 2+ hours apart — WP's 10-minute dedup window doesn't apply:
```php
wp_schedule_single_event( time() - 2 * HOUR_IN_SECONDS, $hook, [ [ 'slug-a' => $obj ] ] );
wp_schedule_single_event( time() - HOUR_IN_SECONDS,     $hook, [ [ 'slug-b' => $obj ] ] );
```
After calling the method under test, assert `$this->cron_hook_count($hook) === 1`.

### `gu_additions` filter is called with 3 args; register with `add_filter(..., 10, 3)`
`get_theme_meta()` applies the filter as `apply_filters('gu_additions', null, $themes, 'theme')`. A listener registered without specifying the accepted-arg count (default 1) will never receive the `$type` argument. Always pass the priority and count explicitly:
```php
add_filter( 'gu_additions', function( $value, $themes, $type ) { ... }, 10, 3 );
```

### `gu_disable_wpcron` path in `get_remote_theme/plugin_meta()` needs no HTTP mock
`Base::get_remote_repo_meta()` has an early return: `if ($disable_wp_cron && !can_update()) return false`. In tests there is no admin user, so `can_update()` always returns false. When `gu_disable_wpcron` is true the method short-circuits before any HTTP call, so no `pre_http_request` mock is needed.

### `get_theme_meta()` — `$all_headers` is set before the first loop
`$all_headers = $this->get_headers('theme')` is set at the top of `get_theme_meta()`, before the `foreach ($paths as $slug => $path)` loop. This matches the Plugin pattern. `gu_additions` theme injection works correctly even in bare environments with no installed themes.

### `get_theme_meta()` branch migration: set `Base::$options` before constructing Theme
`Theme::$options` (private static) is copied from `Base::$options` in the Theme constructor via `get_class_vars('Base', 'options')`, then `load_options()` resets `Base::$options` from the DB. To make `self::$options['current_branch_X']` available inside `get_theme_meta()` during construction, set `Base::$options['current_branch_X']` before `new Theme()`. The value persists in `Theme::$options` for the duration of that `get_theme_meta()` call.

### Multisite `after_theme_row` actions added by `get_remote_theme_meta()`; clean up in `tear_down()`
When `is_multisite()` is true, `get_remote_theme_meta()` adds `after_theme_row` and `after_theme_row_{slug}` actions for each theme in config. Add `remove_all_actions('after_theme_row')` and `remove_all_actions("after_theme_row_{slug}")` to `tear_down()` to prevent cross-test contamination.

### `.git/HEAD` branch override bug in Theme.php (fixed)
The original `.git/HEAD` detection block (lines 228–231) mistakenly wrote to `$git_plugin['branch']` instead of `$git_theme['branch']` — a copy-paste error from Plugin.php. Fixed: the branch is now correctly assigned to `$git_theme['branch']`. Tests for this path create a temporary `.git/HEAD` file in the fixture theme directory and clean it up in a `finally` block.

### `get_theme_meta()` — `! array_key_exists($key, $all_headers)` vs `null === $key` continue branches
Line 171 has two continue conditions: `null === $key` (no 'themeuri'-containing key found) and `! array_key_exists($key, $all_headers)` (key found but not a registered header). The `null` branch is triggered by a `gu_additions` theme whose array has no key matching `stripos($key, 'themeuri')`. The `! array_key_exists` branch is triggered by a `gu_additions` theme with a key that contains 'themeuri' (e.g. `'CustomThemeURI'`) but is NOT in the registered headers returned by `get_headers('theme')`. These are distinct test paths.

### `get_theme_meta()` — `gu_additions` themes without a `'Name'` key skip `local_path` and `.git/HEAD`
The block at lines 210–221 (setting `local_path`, `local_version`, `name`, etc.) only runs when `isset($theme['Name'])` is true. For `gu_additions` injected themes without `'Name'`, these fields are never set. Consequently `isset($git_theme['local_path'])` is false, and the `.git/HEAD` branch-override block (line 228) is also skipped. Additionally, accessing `$paths[$slug]` for gu_additions slugs that are not in `wp_get_themes()` would produce an undefined-key notice — so gu_additions themes should never include `'Name'`.

### `get_theme_meta()` — ThemeID header → non-null `slug_did`
`parse_extra_headers()` reads `$headers['ThemeID']` and sets `$header['did']`. When truthy, `$git_theme['slug_did']` is computed as `slug . '-' . get_did_hash(did)`. Inject a `gu_additions` theme with `'ThemeID' => 'did:example:abc'` to cover this path.

### `get_remote_theme_meta()` — direct fetch when cache is warm; repo object needs `owner`, `enterprise`, `enterprise_api`
When `waiting_for_background_update($repo)` returns false (non-empty cache), `Base::get_remote_repo_meta($repo)` is called directly. This eventually calls `API::api()` → `get_api_url()`, which reads `$this->type->owner`, `$this->type->enterprise`, and `$this->type->enterprise_api` from the repo object. These are not in `make_theme_obj()` defaults. Add them as overrides: `make_theme_obj(['owner' => 'afragen', 'enterprise' => null, 'enterprise_api' => null, ...])`. Detect the direct-fetch path via the `do_action('get_remote_repo_meta', ...)` hook that fires at the end of `get_remote_repo_meta()`; clean up with `remove_all_actions('get_remote_repo_meta')` in `tear_down()`.

### `get_plugin_meta()` — Plugin-exclusive `gu_fix_repo_slug` filter modifies the result key
`gu_fix_repo_slug` is applied at line 224 of Plugin.php after the repo object is assembled. The filter receives the full `$git_plugin` array; its returned `['slug']` value becomes the key in the `$git_plugins` result. There is no Theme equivalent. Always clean up with `remove_all_filters('gu_fix_repo_slug')` in `tear_down()`.

### `get_repo_slugs()` — test via Plugin Singleton as upgrader_object, not null
`get_repo_slugs(string $slug, $upgrader_object = null)` with `$upgrader_object = null` sets it to `$this` (GitHub_API). `GitHub_API` has no declared `$config` property so `get_class_vars('GitHub_API', 'config')` returns `false`, and `(array) false = [false]` causing a TypeError when the foreach tries `$repo->slug`. Instead, pass a real `Plugin` Singleton as the upgrader object: `Singleton::get_instance('Fragen\Git_Updater\Plugin', $this->api)`. For a nonexistent slug the loop finds no match and returns `[]`.

### `waiting_for_background_update(null)` — use `gu_config_pre_process` filter to empty repos
When called with `null`, the method merges Plugin and Theme configs then iterates. In the test environment the fixture plugin IS in Plugin config (with empty cache), so `$waiting` is non-empty and the method returns `true`. To test the false path, add `add_filter('gu_config_pre_process', '__return_empty_array')` before invoking, forcing `$repos = []` → `$waiting = []` → `false`. Clean up with `remove_all_filters('gu_config_pre_process')` in `tear_down()`.

### `get_github_rate_limit_headers()` — mock with `CaseInsensitiveDictionary` as headers value
`get_github_rate_limit_headers()` calls `wp_remote_retrieve_headers($response)->getAll()`. When short-circuited via `pre_http_request`, the filter must return an array whose `headers` key is a `WpOrg\Requests\Utility\CaseInsensitiveDictionary` instance. Use `new CaseInsensitiveDictionary(['x-ratelimit-reset' => (string)(time() + 300)])` for the reset-time test and `new CaseInsensitiveDictionary([])` for the 60-minute default test. Import with `use WpOrg\Requests\Utility\CaseInsensitiveDictionary;`.

### Singleton config injection: always save and restore in `set_up`/`tear_down`
`Fragen\Singleton::get_instance()` returns the **same PHP object** for every call with the same class name within a test process. When you inject into a singleton's `$config` (Plugin, Theme, API, etc.) via `ReflectionProperty`, the modified state persists to every subsequent test class in the suite. A `tear_down()` that only restores `Branch::$options` (or similar) but leaves Plugin/Theme config behind will corrupt API, REST, and other tests that read those singletons later.

Always save the singleton config in `set_up()` and restore it in `tear_down()`:
```php
/** @var array<string, stdClass> */
private array $saved_plugin_config = [];

public function set_up(): void {
    parent::set_up();
    // ... other setup ...
    $singleton                 = Fragen\Singleton::get_instance( 'Fragen\Git_Updater\Plugin', $caller );
    $rp                        = new ReflectionProperty( Plugin::class, 'config' );
    $rp->setAccessible( true );
    $this->saved_plugin_config = $rp->getValue( $singleton ) ?? [];
}

public function tear_down(): void {
    $singleton = Fragen\Singleton::get_instance( 'Fragen\Git_Updater\Plugin', $caller );
    $rp        = new ReflectionProperty( Plugin::class, 'config' );
    $rp->setAccessible( true );
    $rp->setValue( $singleton, $this->saved_plugin_config );
    parent::tear_down();
}
```

Alternatively, for a one-off injection inside a single test method, use a `try/finally` block (the existing `get_repo_slugs` pattern below). The `set_up`/`tear_down` pattern is preferable when the injection spans the entire test class.

### `get_repo_slugs()` dirname match — use `ReflectionProperty` to inject synthetic `$config`
`Plugin::$config` and `Theme::$config` are both declared `private`. To inject a synthetic entry where `dirname($repo->file)` differs from `$repo->slug` (the `-master` suffix scenario), use `ReflectionProperty`:
```php
$ref      = new ReflectionProperty( get_class( $obj ), 'config' );
$ref->setAccessible( true );
$original = $ref->getValue( $obj );
$ref->setValue( $obj, [ 'my-plugin' => (object) [ 'slug' => 'my-plugin', 'file' => 'my-plugin-master/my-plugin.php' ] ] );
try {
    $result = $this->invoke_get_repo_slugs( 'my-plugin-master', $obj );
} finally {
    $ref->setValue( $obj, $original );
}
```
The same pattern applies when the Theme Singleton's config is empty (fixture theme not discovered by `get_theme_meta()` in the test env) — inject a minimal `['test-gu-theme' => (object)['slug' => 'test-gu-theme', 'file' => 'test-gu-theme/style.css']]` and restore in `finally`.

### `get_repo_slugs()` AJAX path — mock via `wp_doing_ajax` filter + real nonce
`wp_doing_ajax()` applies the `wp_doing_ajax` filter, so `add_filter('wp_doing_ajax', '__return_true')` mocks AJAX context without defining `DOING_AJAX`. `check_ajax_referer('updates')` is satisfied by placing `wp_create_nonce('updates')` in `$_REQUEST['_ajax_nonce']` — works with user_id=0 (no logged-in user required). Unset `$_POST['action']`, `$_POST['git_updater_repo']`, and `$_REQUEST['_ajax_nonce']` in `tear_down()`. The nonce must be created fresh each test because `wp_create_nonce` is time-sensitive.

### `Basic_Auth_Loader` — testing private credential helpers via reflection
`get_credentials()`, `get_slug_for_credentials()`, and `get_type_for_credentials()` are all `private`. Access them with `ReflectionMethod::invoke()`. Always call through a `GitHub_API` (or `Language_Pack_API`) instance — not a bare test class — so the `Singleton` namespace resolution works correctly.

### `Basic_Auth_Loader::get_credentials()` Language_Pack_API branch
`Language_Pack_API` extends `API` and can be instantiated directly: `new Language_Pack_API($type)`. Its constructor calls `parent::__construct()` (sets static options/headers from Base) then sets `$this->type = $type`. Use this to cover the `$this instanceof Language_Pack_API` branch in `get_credentials()` (lines 129–131).

### `Basic_Auth_Loader::add_auth_header()` — control credentials via site option
`get_credentials()` reads `get_site_option('git_updater')` directly (not `Base::$options`). To test the Bearer-token path: `update_site_option('git_updater', ['github_access_token' => 'test-token'])` and set `$_REQUEST['slug'] = 'the-slug'`. To test the no-token (type-only) path: leave the site option absent — `$token` resolves to `null`, triggering the `elseif` at line 79.

### `Basic_Auth_Loader::add_accept_header()` — git-server header path
To exercise the `in_array($key, get_running_git_servers())` branch, pass `['headers' => ['github' => $slug]]`. Pre-seed the repo cache with `update_site_option('ghu-' . md5($slug), ['release_asset_download' => 'https://...'])` (no timeout needed — `get_repo_cache($value, false)` ignores timeout) to trigger the `Accept: application/octet-stream` merge. Without the cache entry the `github` key is still unset but no Accept header is added.

### `Basic_Auth_Loader` Remote Install POST path — clean up `$_POST` in `tear_down()`
`get_type_for_credentials()` reads `$_POST['git_updater_api']` and `$_POST['git_updater_repo']`. Always unset both in `tear_down()` to prevent cross-test contamination.

### `waiting_for_background_update($repo)` — injecting `$base` when `$repo->git` is set
The method reads `$this->base::$git_servers[$repo->git]` (line 547). `$this->base` is `null` on a bare `GitHub_API` instance because only `Plugin`, `Theme`, `Init`, and `Branch` constructors set it. To test the `$repo->git` branch from a `GitHub_API` instance, inject via `ReflectionProperty`:
```php
$rp = new ReflectionProperty( $this->api, 'base' );
$rp->setAccessible( true );
$rp->setValue( $this->api, Singleton::get_instance( 'Fragen\Git_Updater\Base', $this->api ) );
```

### `get_repo_slugs(slug, null)` — invoke on Plugin instance, not GitHub_API
When `$upgrader_object = null`, the method sets `$upgrader_object = $this`. If `$this` is `GitHub_API` (no `$config`), `get_class_vars` returns `false` and `foreach ((array) false ...)` causes a TypeError. Invoke via reflection on a `Plugin` Singleton instead so `$this->plugin_obj->config` resolves cleanly:
```php
$rm     = $this->api->get_reflection_method( $this->plugin_obj, 'get_repo_slugs' );
$result = $rm->invoke( $this->plugin_obj, 'nonexistent-slug', null );
```

### `Skip_Updates` plugin stub via `eval()` in `override_dot_org()` tests
`override_dot_org()` checks `class_exists('\Fragen\Skip_Updates\Bootstrap')`. To cover that branch in tests, create a stub with `eval()` — PHP allows `namespace` declarations inside `eval`:
```php
private function ensure_skip_updates_stub(): void {
    if ( ! class_exists( '\Fragen\Skip_Updates\Bootstrap' ) ) {
        eval( 'namespace Fragen\\Skip_Updates; class Bootstrap {}' );
    }
}
```
The class_exists guard prevents "Cannot redeclare class" errors across test runs. The `skip_updates` site option controls which slugs are matched; delete it inline after each test.

### `populate_api_data()` — tags cache holds version-string arrays, not raw API objects
`$cache['tags']` stores the output of `parse_tag_response()` — an array of version name strings like `['1.0.0', '0.9.0']`. `parse_tags()` then iterates these and builds the download-URL map. Seed tags tests with string arrays:
```php
$this->seed_cache( [ 'tags' => [ '1.0.0', '0.9.0' ] ] );
```

### `populate_api_data()` meta case — pass `$this->api->type` as `$repo`
`add_meta_repo_object()` reads `$this->type->repo_meta` from the `$repo_api` argument. The method sets `$repo->repo_meta = $value` on the `$repo` argument. For the assignment to reach `$repo_api->type->repo_meta`, pass `$this->api->type` as `$repo` so both point to the same object:
```php
$this->api->populate_api_data( $this->api->type, $this->api );
$this->assertSame( '2024-01-01T00:00:00Z', $this->api->type->last_updated );
```

### `WP_DEBUG` is `false` in the wp-env test container; annotate guarded blocks
The wp-env `wp-config.php` defines `WP_DEBUG = false`. Any code inside `if (defined('WP_DEBUG') && WP_DEBUG)` is unreachable in tests. Annotate such blocks with `// @codeCoverageIgnoreStart` / `// @codeCoverageIgnoreEnd` rather than trying to test them.

### `set_readme_info()` — `$type->sections` is an array after the merge, not stdClass
After `set_readme_info()` runs, `$this->type->sections` is the result of `array_merge((array)$sections, (array)$readme['sections'])` — a plain PHP array. Use array access (`$this->type->sections['other_notes']`), not object access (`->other_notes`), in assertions.

### `get_release_asset_redirect()` — simulate redirect by calling `set_redirect()` in `pre_http_request` mock
The `requests-requests.before_redirect` action only fires during real HTTP redirects; `pre_http_request` short-circuits before it. To test the success path (lines that cache and return `$this->redirect`), call `$api->set_redirect($url)` inside the `pre_http_request` filter callback before returning the mock response. This sets `$this->redirect` as if the redirect action had fired.

### `gu_post_api_response_body` filter — wrap cache-entry in `md5($url)` key to test line 275
`API::api()` checks `if (!empty($response[md5($url)]) && is_array($response[md5($url)]))` after applying `gu_post_api_response_body`. To exercise the unwrap path, pre-compute `$url = $this->api->get_api_url($endpoint)` then add a filter that returns `[md5($url) => $response]`. Clean up with `remove_all_filters('gu_post_api_response_body')` in `tear_down()`.

### `settings_hook()` lambda — fire `do_action('gu_add_settings', ...)` to cover the callback body
`settings_hook($git)` registers a lambda on `gu_add_settings` that calls `$git->add_settings($auth_required)`. The constructor calls `settings_hook($this)`, so the registered `$git` is the API instance. Fire `do_action('gu_add_settings', ['github_private' => false, 'github_enterprise' => false])` in a test to invoke the lambda and cover that line.

### `construct_download_link()` dev asset path — seed `release_assets` with both `assets` and `dev_assets` keys
Lines 171-174 (the `gu_dev_release_asset` filter block) require `release_assets['dev_assets']` to be non-empty and `version_compare(asset_version, dev_asset_version, '<')` to return true. Seed the cache with `['assets' => ['1.0.0' => stable_url], 'dev_assets' => ['2.0.0-beta1' => dev_url]]` and add `add_filter('gu_dev_release_asset', '__return_true')`. The `gu_dev_release_asset` filter cleanup is already in `Test_GitHub_API_DownloadLink_ReleaseAsset::tear_down()`.

### `get_remote_api_*` tri-state returns — `null` for "nothing found", `false` only for WP_Error
The seven `get_remote_api_*` methods in `API_Common` return `bool|null`:
- `true` — data cached.
- `null` — ran fine, nothing there (no tags, no readme, etc.); a placeholder is cached.
- `false` — `WP_Error` (network/DNS failure); retry on next update check.

Any existing test that used `assertFalse()` for a "nothing found" scenario (HTTP 404, or error-cache hit where `api()` returns literal `false`) must use `assertNull()` instead. The `assertFalse()` path is now reserved exclusively for WP_Error mocks via `pre_http_request`.

### Sub-cache methods respect the main timeout — no `timeout=false`
`get_remote_api_tag()`, `get_remote_api_changes()`, `get_remote_api_readme()`, and `get_remote_api_assets()` all use `get_repo_cache($slug) ?: []` (respects timeout). When the main cache is expired these methods return `false` for their sub-key and make a fresh HTTP call. **Cache-hit tests for these methods must seed a future timeout** — tests using `seed_cache()` or `seed_main_cache()` already do this correctly. The `?: []` guard converts a `false` return (expired cache) to `[]` so that subsequent `$cache['key'] ?? false` array accesses are safe under `convertNoticesToExceptions`.

### `Rest_Update` non-object transient branches — priority-15 filter insertion pattern
`Rest_Update::update_plugin()` and `update_theme()` each register a closure at priority 15 on `site_transient_update_plugins` / `site_transient_update_themes`. Inside the closure, lines like `if (!is_object($current)) { $current = new stdClass(); ... }` guard against a false/null transient. However, `Plugin::update_site_transient()` and `Theme::update_site_transient()` are also registered at priority 15 (via `load_pre_filters()` during WordPress init) and run first — they convert `false` to `stdClass` before the source closure sees it. A priority-5 filter that returns `false` is overridden by the priority-15 Plugin/Theme filter.

To cover lines 119-120 (plugin) and 192-193 (theme): delete the site transient, then add a `fn() => false` filter **also at priority 15** AFTER WordPress has already registered Plugin/Theme's filter but BEFORE `update_plugin()`/`update_theme()` registers the source closure. Registration order within the same priority determines execution order. The sequence becomes:
1. Plugin/Theme filter (15, pos1): `false` → `stdClass`
2. Test filter (15, pos2): `stdClass` → `false`
3. Source closure (15, pos3): `false` → `!is_object` → guarded lines execute.

```php
delete_site_transient( 'update_plugins' );
add_filter( 'site_transient_update_plugins', fn() => false, 15, 1 );
// Then call update_plugin() — it registers the source closure at priority 15 pos3.
```

### `get_release_asset_redirect()` in REST context — use GitHub API URL, inject API singleton type
When `REST_API::get_api_data()` calls `get_release_asset_redirect($repo_cache['release_asset'], true)` it reads `$this->type->slug` on the shared `API` singleton to look up the cache key. A bare `stdClass()` without `slug` resolves to `md5('')` — a wrong cache key. Inject the correct slug via `ReflectionProperty`:
```php
$api_singleton  = Singleton::get_instance( 'Fragen\Git_Updater\API\API', new REST_API() );
$rp             = new ReflectionProperty( get_class( $api_singleton ), 'type' );
$rp->setAccessible( true );
$saved_type     = $rp->getValue( $api_singleton );
$type_obj       = new stdClass();
$type_obj->slug = 'test-gu-plugin';
$rp->setValue( $api_singleton, $type_obj );
// ... test ...
$rp->setValue( $api_singleton, $saved_type ); // restore in finally/tear_down
```
Also: the `release_asset` value in the seeded cache must be a URL interceptable by `pre_http_request` — use a GitHub API URL (`https://api.github.com/repos/owner/repo/releases/assets/1234`) rather than `https://example.com/...`, since the mock only intercepts `api.github.com` requests.

### Upgrader skin HTML output — use `gu_get_upgrader_skin` filter, not absorber buffers

`WP_Upgrader_Skin::feedback()` calls `show_message()`, which echoes HTML and then calls `wp_ob_end_flush_all()`. That function flushes **every** PHP output buffer down to level 0 on its first call. Any subsequent echo (from more feedback calls, or from `header()`/`footer()`/`after()`) goes straight to stdout.

The `show_message()` function_exists override never registers: `Rest_Update.php` has a file-level `require_once class-wp-upgrader.php`, which loads `misc.php` (where `show_message()` is defined without a `function_exists` guard) as a side-effect of `Bootstrap::run()` → `REST_API::load_hooks()` → `Singleton::get_instance('REST\Rest_Update', ...)`. This happens during the `plugins_loaded` hook — before PHPUnit parses any test file.

**Fix:** `Install::get_upgrader()` exposes a `gu_get_upgrader_skin` filter. Register a `Silent_Upgrader_Skin` in `set_up()` so `show_message()` is never invoked:

```php
// In test file (after requiring class-wp-upgrader.php):
if ( ! class_exists( 'Silent_Upgrader_Skin' ) ) {
    class Silent_Upgrader_Skin extends WP_Upgrader_Skin {
        public function header() {}
        public function footer() {}
        public function error( $errors ) {}
        public function feedback( $feedback, ...$args ) {}
    }
}

// In set_up():
add_filter( 'gu_get_upgrader_skin', fn( $skin, $type ) => new Silent_Upgrader_Skin( [ 'type' => $type ] ), 10, 2 );

// In tear_down():
remove_all_filters( 'gu_get_upgrader_skin' );
```

Then a simple `ob_start()`/`ob_end_clean()` around the `install()` call is enough as a safety net.

### `do_action('admin_enqueue_scripts')` in tests — call `set_current_screen()` first
Firing the `admin_enqueue_scripts` action without a screen context causes WP Site Health (`class-wp-site-health.php`) to throw "Attempt to read property 'id' on null". Always call `set_current_screen('plugins')` (or the appropriate screen slug) before firing this action in tests.

### `get_git_icon()` plugin-type path — call from inside a filter with 'plugin' in its name
`get_git_icon()` calls `current_filter()` to determine type: if the filter name contains 'plugin', type='plugin'; otherwise type='theme'. When called directly (no active filter), `current_filter()` returns '' → type='theme'. To test the plugin path, wrap the call inside `apply_filters('plugin_action_links_gu_test', [])` so `current_filter()` returns a string containing 'plugin'.

### `fix_misnamed_directory()` lines 566–571 — only reachable when `$new_source = ''`
`new_source` is always set to `trailingslashit(remote_source) . $slug` before `fix_misnamed_directory()` is called, so `basename($new_source)` always equals `$slug` — meaning line 562's guard catches the slug match first. The ONLY way to reach lines 566–571 is when `$new_source = ''` (Plugin_Upgrader with no hook_extra and no AJAX sets slug='', new_source=''). In that case `basename('')=''` ≠ any non-empty slug → falls through to line 566. Test via `ReflectionMethod` calling `fix_misnamed_directory` directly with an empty `$new_source` string and a non-config slug.

### `Base::$options` is a static property — restore in `tear_down()` after direct manipulation
When tests set `Base::$options = [...]` directly (e.g. to test `set_defaults()` paths), restore it in `tear_down()`: `Base::$options = get_site_option('git_updater', [])`. Otherwise subsequent tests inherit the mutated static state.

### `get_remote_repo_meta()` null-API early return — use `$repo->git = 'bitbucket'`
`get_repo_api('bitbucket', $repo)` returns null when no Bitbucket add-on is installed (the Bitbucket API class is not registered via `gu_get_repo_api` filter). This is the simplest way to exercise the `$api === null → return false` branch at line 328 without installing any add-on plugin.

### `upgrader_source_selection()` remote-install path — inject `Install::$install` via ReflectionProperty
Lines 513–515 (the remote install source path) are only reachable when `$repo` is empty AND `Install::$install['git_updater_install_repo']` is set. `Install::$install` is `protected static`; set it via `ReflectionProperty::setValue(null, [...])`. Set `$_POST['git_updater_repo'] = '1'` to bypass the early return at line 502. Restore `Install::$install` in a `finally` block.

### `do_action('init')` — unregister block binding sources added as side-effects
When a test calls `do_action('init')`, ALL registered `init` callbacks fire — including the active theme's block bindings registration. `WP_Block_Bindings_Registry::register` throws a "doing it wrong" notice when a source is registered a second time; `WP_UnitTestCase` treats unexpected incorrect-usage notices as test failures. Snapshot the registered sources in `set_up()` and unregister any new ones in `tear_down()`.

Additionally, if the binding source was already registered before `set_up()` runs (i.e. it is in the snapshot), the `tear_down()` cleanup won't remove it — so calling `do_action('init')` will still trigger a duplicate-registration notice. Fix: **unregister all currently-registered sources immediately before calling `do_action('init')`** in the test body. `do_action('init')` then re-registers them fresh, and `tear_down()` leaves them intact (they're in the snapshot).
```php
if ( class_exists( 'WP_Block_Bindings_Registry' ) ) {
    foreach ( array_keys( WP_Block_Bindings_Registry::get_instance()->get_all_registered() ) as $name ) {
        unregister_block_bindings_source( $name );
    }
}
do_action( 'init' );
```
```php
private array $pre_registered_bindings = [];

public function set_up(): void {
    parent::set_up();
    if ( class_exists( 'WP_Block_Bindings_Registry' ) ) {
        $this->pre_registered_bindings = array_keys(
            WP_Block_Bindings_Registry::get_instance()->get_all_registered()
        );
    }
}

// In tear_down(), before parent::tear_down():
if ( class_exists( 'WP_Block_Bindings_Registry' ) ) {
    foreach ( array_keys( WP_Block_Bindings_Registry::get_instance()->get_all_registered() ) as $name ) {
        if ( ! in_array( $name, $this->pre_registered_bindings, true ) ) {
            unregister_block_bindings_source( $name );
        }
    }
}
```

### Multisite-only failures: `WP_Theme::get_allowed_on_network()` static cache
CI runs both single-site and multisite suites; locally only single-site runs. On single-site, `WP_Theme::is_allowed('network')` returns `true` immediately. On multisite it calls `get_allowed_on_network()`, which uses a `static $allowed_themes` local variable. That cache is populated early in the test run, so `update_site_option('allowedthemes', ...)` in a test has no effect on it.

Fix: use the **`allowed_themes`** filter (the old MU-era filter applied inside `get_allowed_on_network()` on every call, outside the static-cache guard) and clean up with `remove_all_filters('allowed_themes')` in `tear_down()`:
```php
add_filter( 'allowed_themes', fn( $themes ) => array_merge( $themes, [ 'my-theme' => true ] ) );
```
**Do NOT use `network_allowed_themes`** — that filter is only applied in `WP_Theme::get_allowed()` (a separate admin-listing method), which is never called by `is_allowed('network')`. The check inside `is_allowed()` is `! empty( $allowed[ $stylesheet ] )`, so the slug must be a **key** (with a truthy value) in the returned array.

### Multisite-only failures: `Plugin::get_remote_plugin_meta()` `after_plugin_row` guard
`get_remote_plugin_meta()` only registers `after_plugin_row_*` actions when `! is_multisite() || is_network_admin()`. On single-site the first clause is true; on multisite CI (not in network admin) both are false and the action is never registered. Fix: call `set_current_screen('plugins-network')` when `is_multisite()` is true to satisfy `is_network_admin()`, and reset with `$GLOBALS['current_screen'] = null` in `tear_down()`.

### Bootstrap.php testing: coverage is per-test, not per-bootstrap
PHPUnit tracks coverage between each test's `setUp`/`tearDown`, not from the start of the run. Code executed during `tests/bootstrap.php` (plugin load via `plugins_loaded`) is **not** counted as covered. Methods like `Bootstrap::run()` that fire during the bootstrap need an explicit test that calls them.

### `PLUGIN_FILE` is a namespaced constant
`git-updater.php` declares `const PLUGIN_FILE = __FILE__` inside `namespace Fragen\Git_Updater`. Test files (global namespace) must use the fully qualified form: `\Fragen\Git_Updater\PLUGIN_FILE`.

### `GU_Freemius::init()` namespace guard
The original guard `function_exists('gu_fs')` checked the global namespace while `gu_fs()` is defined in `Fragen\Git_Updater` — so the guard never fired, causing a "Cannot redeclare" fatal on any second `init()` call. Fixed to `function_exists('\Fragen\Git_Updater\gu_fs')`. When writing tests that call `Bootstrap::run()`, ensure this fix is in place.

### `rename_on_activation()` requires slash in `current_action()` result
`get_file_without_did_hash()` does `explode('/', $file, 2)` expecting at least two parts. If `current_action()` returns a string without `/` (e.g. `''`), the explode returns a single-element array and the `list($slug, $file)` destructuring triggers an undefined-offset notice, which becomes an exception under `convertNoticesToExceptions="true"`. Always fire `rename_on_activation()` via `do_action('activate_git-updater/git-updater.php')` so `current_action()` returns a slash-containing string.

### FAIR namespace shim for `check_update_api_redirect()`
`check_update_api_redirect()` conditionally adds a filter only when `\Fair\Default_Repo\get_default_repo_domain()` exists. Define it in `tests/fixtures/fair-default-repo-shim.php` (with an `if (!function_exists(...))` guard) and `require_once` it in `set_up()`. To cover the arrow-function closure body, call `apply_filters('gu_api_domain', '')` after registering the filter.

### `get_available_languages()` is not empty in wp-env
`get_available_languages()` scans `WP_LANG_DIR` for `.mo` files. In wp-env the languages directory ships with `de_DE`, `en_GB`, `es_ES`, `ja_JP`, and `de_CH` installed. Any code that falls back via `! empty($locales) ? $locales : [get_locale()]` will never use `get_locale()` in wp-env. Tests that rely on `$locales = ['en_US']` must force it via the filter WordPress provides:
```php
// In set_up() — override for the whole test class:
add_filter( 'get_available_languages', fn() => [ 'en_US' ] );

// In tear_down():
remove_all_filters( 'get_available_languages' );

// Per-test override (runs after the set_up callback; last callback wins):
add_filter( 'get_available_languages', fn() => [ 'de_DE' ] );
```

### `wp_get_installed_translations()` — use pre-seeded WordPress test fixtures, not written .po files
`wp_get_installed_translations('plugins')` does read `.po` files from `WP_LANG_DIR/plugins/`, but manually-written `.po` files in tests are not reliably parsed in the wp-env container (format issues, caching, etc.). Instead, use the pre-seeded WordPress test-suite translation fixtures that are already present:
- `internationalized-plugin` — has `de_DE` and `es_ES` with `PO-Revision-Date: 2020-10-20 17:11+0200`

To cover the `$translation_mod = strtotime($translations[$slug][$locale]['PO-Revision-Date'])` branch, inject a repo whose slug matches one of those fixtures (e.g. `internationalized-plugin`, locale `de_DE`) and set `language_packs->de_DE->updated = '2030-01-01 00:00:00'`. No file I/O needed.

### Driving `current_filter()` in static method tests — push to `$wp_current_filter` directly
`Language_Pack::update_site_transient()` (and similar static methods) branch on `current_filter()`. Wrapping the call in `apply_filters(...)` fires all registered callbacks at that priority — including `Plugin::update_site_transient` at priority 15, which accesses properties (`->git`, `->file`, etc.) that minimal test-repo stubs lack.

Instead, push the filter name onto `$GLOBALS['wp_current_filter']` directly so only the target method is called:
```php
private function run_as_plugin_filter( stdClass $transient ): stdClass {
    global $wp_current_filter;
    $wp_current_filter[] = 'site_transient_update_plugins';
    $result              = Language_Pack::update_site_transient( $transient );
    array_pop( $wp_current_filter );
    return $result;
}
```
This is safe because `current_filter()` reads `end($wp_current_filter)` and the array is cleaned up immediately.

### `is_admin()` in tests — requires `set_current_screen()`
`is_admin()` returns `false` by default in the wp-env test container. To enter code guarded by `if ( is_admin() )`, call `set_current_screen('update-core')` (or any admin screen name) before the assertion. Reset in `tear_down()` with `set_current_screen('front')`. Also clean up any actions registered inside the guarded block:
```php
public function tear_down(): void {
    set_current_screen( 'front' );
    remove_all_actions( 'admin_notices' );
    remove_all_actions( 'network_admin_notices' );
    parent::tear_down();
}
```

### Switch `case` labels are dispatch opcodes — fall-through does NOT cover them
In a PHP `switch`, each `case 'value':` compiles to a comparison opcode that Xdebug tracks as a coverable line. This opcode is only executed when the switch **dispatch chain reaches it** — i.e., when no earlier case matched. Fall-through from a previous `case` skips the dispatch entirely, so the label line stays uncovered.

Example: `case 'git':` after `case 'waiting':` (with `// no break`) requires a dedicated test that passes `'git'` (or any value that the dispatch evaluates but doesn't match earlier) to cover it. Falling through from `'waiting'` is not sufficient.

### Mocking `gu_fs()` via `$GLOBALS['gu_fs']`
`gu_fs()` returns the global `$gu_fs` object (Freemius SDK). Replace it in tests with an anonymous-class mock to control methods like `is_not_paying()`:
```php
$orig_fs          = $GLOBALS['gu_fs'] ?? null;
$GLOBALS['gu_fs'] = new class {
    public function is_not_paying(): bool { return false; }
};
// ... test code ...
$GLOBALS['gu_fs'] = $orig_fs;
```
Restore `$orig_fs` in the same test method (not `tear_down()`) since other tests need the real Freemius object.
